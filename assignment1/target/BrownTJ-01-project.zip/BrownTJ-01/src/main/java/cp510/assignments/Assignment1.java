package cp510.assignments;

import uw.syp.java.tools.Turtle;

public class Assignment1
{
    public static void main( String[] args )
    {
        Turtle  toots   = new Turtle();
        toots.fillCircle( 64 );
    }
}